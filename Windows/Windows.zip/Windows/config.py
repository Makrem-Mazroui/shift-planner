import os
import sys

# Determine the base directory
if getattr(sys, 'frozen', False):
    # Running as compiled .app or .exe
    if sys.platform == 'darwin':
        # macOS .app structure: AppName.app/Contents/MacOS/Executable
        # We want to go up 4 levels to get to the folder CONTAINING the .app
        BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(sys.executable))))
    else:
        # Windows .exe
        BASE_DIR = os.path.dirname(sys.executable)
else:
    # Running as python script
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Define the Teams directory
TEAMS_DIR = os.path.join(BASE_DIR, "teams")

if not os.path.exists(TEAMS_DIR):
    os.makedirs(TEAMS_DIR)
