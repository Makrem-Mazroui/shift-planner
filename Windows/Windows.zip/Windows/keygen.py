import hashlib
import base64
import os
from datetime import datetime, timedelta
try:
    from cryptography.hazmat.primitives import serialization, hashes
    from cryptography.hazmat.primitives.asymmetric import padding
except ImportError:
    print("Error: Run 'pip install cryptography'")
    exit()

def generate_license(hwid, days_valid=730):
    try:
        # 1. Load Private Key
        if not os.path.exists("private.pem"):
            return None, "Error: private.pem not found!"
            
        with open("private.pem", "rb") as key_file:
            private_key = serialization.load_pem_private_key(
                key_file.read(), password=None
            )

        # 2. Prepare Data
        exp_date = datetime.now() + timedelta(days=days_valid)
        exp_str = exp_date.strftime("%Y-%m-%d")
        payload = f"{hwid}|{exp_str}".encode('utf-8')

        # 3. Sign Data (Create Digital Signature)
        signature = private_key.sign(
            payload,
            padding.PKCS1v15(),
            hashes.SHA256()
        )

        # 4. Pack License (Payload + Signature)
        license_data = base64.b64encode(payload).decode() + "." + base64.b64encode(signature).decode()
        return license_data, exp_str

    except Exception as e:
        return None, str(e)

if __name__ == "__main__":
    print("--- RSA LICENSE GENERATOR ---")
    hwid = input("Enter Client HWID: ").strip()
    days = input("Days (default 730): ").strip()
    if not days: days = 730
    else: days = int(days)

    key, date = generate_license(hwid, days)
    print("\n" + "="*50)
    print(f"EXPIRATION: {date}")
    print("LICENSE KEY (Copy all of it):")
    print(key)
    print("="*50 + "\n")