import uuid
import calendar
from datetime import datetime, timedelta
from utils.helpers import try_parse_date

def generate_ics_content(member_name, shifts, times):
    ics_lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        f"PRODID:-//ShiftPlanner//{member_name}//EN",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        f"X-WR-CALNAME:Shifts - {member_name}",
        "BEGIN:VTIMEZONE",
        "TZID:Europe/Prague",
        "BEGIN:STANDARD",
        "DTSTART:19701025T030000",
        "RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU",
        "TZOFFSETFROM:+0200",
        "TZOFFSETTO:+0100",
        "TZNAME:CET",
        "END:STANDARD",
        "BEGIN:DAYLIGHT",
        "DTSTART:19700329T020000",
        "RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU",
        "TZOFFSETFROM:+0100",
        "TZOFFSETTO:+0200",
        "TZNAME:CEST",
        "END:DAYLIGHT",
        "END:VTIMEZONE"
    ]

    now_str = datetime.now().strftime("%Y%m%dT%H%M%SZ")

    for s in shifts:
        start_date = s['start']
        roles = {
            "Early": ("early", times["early_s"], times["early_e"]),
            "Central": ("central", times["central_s"], times["central_e"]),
            "Late": ("late", times["late_s"], times["late_e"]),
            "Weekend": ("weekend", times["weekend_s"], times["weekend_e"]),
            "On-Call": ("oncall", times["oncall_s"], times["oncall_e"])
        }

        for role_name, (key, t_start, t_end) in roles.items():
            val = s.get(key)
            if not val or val == "VACANT": continue
            
            is_assigned = False
            if isinstance(val, list):
                if member_name in val: is_assigned = True
            elif val == member_name:
                is_assigned = True
            
            if is_assigned:
                for i in range(7):
                    day_date = start_date + timedelta(days=i)
                    is_weekend = day_date.weekday() >= 5
                    
                    if role_name == "Weekend" and not is_weekend: continue
                    if role_name != "Weekend" and role_name != "On-Call" and is_weekend: continue
                    
                    try:
                        sh, sm = map(int, t_start.split(':'))
                        eh, em = map(int, t_end.split(':'))
                        
                        dt_start = day_date.replace(hour=sh, minute=sm, second=0)
                        dt_end = day_date.replace(hour=eh, minute=em, second=0)
                        
                        if dt_end < dt_start:
                            dt_end += timedelta(days=1)

                        fmt = "%Y%m%dT%H%M%S"
                        
                        ics_lines.append("BEGIN:VEVENT")
                        ics_lines.append(f"UID:{uuid.uuid4()}@shiftplanner")
                        ics_lines.append(f"DTSTAMP:{now_str}")
                        ics_lines.append(f"DTSTART;TZID=Europe/Prague:{dt_start.strftime(fmt)}")
                        ics_lines.append(f"DTEND;TZID=Europe/Prague:{dt_end.strftime(fmt)}")
                        ics_lines.append(f"SUMMARY:Shift: {role_name}")
                        ics_lines.append(f"DESCRIPTION:Role: {role_name}\\nAssigned to: {member_name}")
                        ics_lines.append("END:VEVENT")

                    except: pass 

    ics_lines.append("END:VCALENDAR")
    return "\n".join(ics_lines)

def render_html(shifts, year, plan_type, shift_config, times, holidays, absences, comp_days, output_path):
    if absences is None: absences = []
    if comp_days is None: comp_days = [3, 4]
    
    is_shift_mode = plan_type in ["shift-plan", "both"]
    is_oncall_mode = plan_type in ["oncall", "both"]
    show_early = is_shift_mode and ("Early" in shift_config)
    show_central = is_shift_mode and ("Central" in shift_config)
    show_late = is_shift_mode and ("Late" in shift_config)
    show_weekend = is_shift_mode and ("Weekend" in shift_config)
    show_oncall = is_oncall_mode

    ROLE_COLORS = {
        "Early": "#fff9c4", "Central": "#ffe0b2", "Late": "#d6d6d6",
        "Weekend": "#a8e6cf", "On-Call": "#d63031"
    }

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
    <style>
        body {{ font-family: 'Segoe UI', Arial, sans-serif; text-align: center; background-color: #f4f7f6; padding: 20px; }}
        .header-title {{ font-size: 32px; font-weight: bold; margin-bottom: 5px; color: #2c3e50; }}
        .legend-container {{ background: white; padding: 15px; margin: 0 auto 30px auto; max-width: 1000px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: flex; flex-direction: column; gap: 10px; align-items: center; }}
        .legend-row {{ display: flex; gap: 15px; flex-wrap: wrap; justify-content: center; }}
        .role-badge {{ font-weight: bold; padding: 4px 10px; border-radius: 4px; color: black; font-size: 13px; border: 1px solid #ccc; }}
        .calendar-container {{ width: 100%; margin: 0 auto; display: flex; flex-direction: column; align-items: center; }}
        .month-box {{ background: white; margin-bottom: 40px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); overflow: hidden; width: fit-content; }}
        .month-name {{ background-color: #34495e; color: white; font-weight: bold; font-size: 22px; padding: 10px; text-align: left; padding-left: 20px; }}
        .month-table {{ border-collapse: collapse; width: auto; margin: 0; font-size: 12px; table-layout: fixed; }}
        .month-table th, .month-table td {{ border: 2px solid #bdc3c7; padding: 6px; text-align: center; vertical-align: middle; }}
        .col-role {{ width: 60px; font-weight: bold; font-size: 11px; }}
        .col-names {{ width: 380px; text-align: left; padding-left: 10px; white-space: normal; line-height: 1.4; }}
        .col-week {{ width: 50px; font-size: 38px; font-weight: bold; color: #d63031; background: #fff5f5; border-bottom: 3px solid #34495e !important; vertical-align: middle !important; }}
        .col-day {{ width: 40px; }}
        .day-header {{ background-color: #3498db; font-weight: bold; color: white; }}
        .date-cell {{ color: #2d3436; font-size: 13px; }}
        .empty-cell {{ background-color: #fdfdfd; }}
        .time-label {{ display: block; font-size: 9px; color: #555; margin-top: 2px; }}
        .weekend-non-working {{ background-color: #636e72 !important; color: #b2bec3; }}
        .oncall-row .col-role {{ background-color: #d63031 !important; color: white !important; }}
        .oncall-row .col-role .time-label {{ color: #ffcccc !important; }}
        .oncall-row .date-cell, .oncall-row .empty-cell {{ background-color: #d63031; color: white; font-weight: bold; border-color: #d63031; }}
        .divider td {{ border-bottom: 3px solid #34495e !important; }}
        .holiday-cell {{ color: #0984e3 !important; font-weight: bold; cursor: help; background-color: #eaf2f8; }}
        .absence-section {{ padding: 10px 20px; background-color: #fff8f8; border-top: 2px solid #bdc3c7; text-align: left; }}
        .absence-title {{ font-size: 14px; font-weight: bold; color: #c0392b; margin-bottom: 5px; text-transform: uppercase; }}
        .absence-item {{ font-size: 13px; color: #555; margin-bottom: 3px; padding-left: 10px; border-left: 3px solid #c0392b; }}
    </style>
    </head>
    <body>
        <div class="header-title">Shift & On-Call Schedule {year}</div>
        <div class="legend-container">
            <div class="legend-row">
                {f'<span class="role-badge" style="background:{ROLE_COLORS["Early"]}">Early ({times["early_s"]}-{times["early_e"]})</span>' if show_early else ''}
                {f'<span class="role-badge" style="background:{ROLE_COLORS["Central"]}">Central ({times["central_s"]}-{times["central_e"]})</span>' if show_central else ''}
                {f'<span class="role-badge" style="background:{ROLE_COLORS["Late"]}">Late ({times["late_s"]}-{times["late_e"]})</span>' if show_late else ''}
                {f'<span class="role-badge" style="background:{ROLE_COLORS["Weekend"]}">Weekend ({times["weekend_s"]}-{times["weekend_e"]})</span>' if show_weekend else ''}
                {f'<span class="role-badge" style="background:{ROLE_COLORS["On-Call"]}; color:white;">On-Call ({times["oncall_s"]}-{times["oncall_e"]})</span>' if show_oncall else ''}
                <span class="role-badge" style="background:#eaf2f8; color:#0984e3; border:1px solid #0984e3">PH = Public Holiday</span>
                <span class="role-badge" style="background:#ff0000; color:white; border:1px solid red">VACANT = Unassigned</span>
                <span class="role-badge" style="background:#b2bec3; color:white;">OFF = Comp Day</span>
                <span class="role-badge" style="background:#ff0000; color:white; border:1px solid red">V-OFF = Vacant Comp Day</span>
            </div>
        </div>
        <div class="calendar-container">
    """

    months_data = {}
    for s in shifts:
        m_key = (s['start'].year, s['start'].month)
        if m_key not in months_data: months_data[m_key] = []
        months_data[m_key].append(s)

    for (y, m), m_shifts in sorted(months_data.items()):
        month_name = calendar.month_name[m]
        m_start_dt = datetime(y, m, 1)
        m_end_dt = datetime(y, m, calendar.monthrange(y, m)[1])
        
        month_absences = []
        for rec in absences:
            try:
                a_start = try_parse_date(rec['start'])
                a_end = try_parse_date(rec['end'])
                if a_start and a_end and a_start <= m_end_dt and a_end >= m_start_dt:
                    month_absences.append(rec)
            except: pass

        html += f"""
        <div class="month-box">
            <div class="month-name">{month_name} {y}</div>
            <table class="month-table">
                <tr class="day-header">
                    <td class="col-role">Role</td><td class="col-names">Member(s)</td>
                    <td class="col-day">Mon</td><td class="col-day">Tue</td><td class="col-day">Wed</td>
                    <td class="col-day">Thu</td><td class="col-day">Fri</td><td class="col-day">Sat</td>
                    <td class="col-day">Sun</td><td class="col-week">Week</td>
                </tr>
        """
        for s in m_shifts:
            start_day = s['start']
            wk = s['week_num']
            weekend_worker_name = s.get('weekend', "")
            
            def get_day_cells(role_type, assigned_names):
                c = ""
                for i in range(7):
                    d = start_day + timedelta(days=i)
                    is_weekend = (d.weekday() >= 5) 
                    hol_name = holidays.get(d)
                    classes = ["date-cell"]
                    cell_style = ""
                    cell_content = f"{d.day} PH" if hol_name else f"{d.day}"
                    
                    if role_type in ["Early", "Central", "Late"]:
                        is_ww_in_role = False
                        if isinstance(assigned_names, list):
                            if weekend_worker_name in assigned_names: is_ww_in_role = True
                        elif assigned_names == weekend_worker_name:
                            is_ww_in_role = True
                        
                        if hol_name: classes.append("holiday-cell")
                        elif is_weekend: classes.append("weekend-non-working")
                        else:
                            if is_ww_in_role and (d.weekday() in comp_days):
                                is_mixed = isinstance(assigned_names, list) and len(assigned_names) > 1
                                is_fully_covered = isinstance(assigned_names, list) and len(assigned_names) > 1
                                if is_mixed: cell_content = f"<span style='color:#c0392b; font-weight:bold; font-size:11px;'>{weekend_worker_name}<br>OFF</span>"
                                elif is_fully_covered: classes.append("weekend-non-working"); cell_content = "OFF"
                                else: cell_style = "background-color: #ff0000; color: white; font-weight: bold;"; cell_content = "V-OFF"

                    elif role_type == "Weekend":
                        if not is_weekend: classes.append("empty-cell") 
                        else:
                            cell_style = f"background-color: {ROLE_COLORS['Weekend']};"
                            if hol_name: classes.append("holiday-cell")
                    
                    class_str = " ".join(classes)
                    title_attr = f"title='{hol_name}'" if hol_name else ""
                    style_attr = f"style='{cell_style}'" if cell_style else ""
                    c += f"<td class='{class_str}' {style_attr} {title_attr}>{cell_content}</td>"
                return c

            visible_rows = [r for r in [show_early, show_central, show_late, show_weekend, show_oncall] if r]
            rowspan = len(visible_rows)
            first_row = True
            
            last_visible_role = ""
            if show_oncall: last_visible_role = "On-Call"
            elif show_weekend: last_visible_role = "Weekend"
            elif show_late: last_visible_role = "Late"
            elif show_central: last_visible_role = "Central"
            elif show_early: last_visible_role = "Early"

            def render_row(label, name_val, is_list=False, time_str=""):
                nonlocal first_row
                classes = []
                if label == last_visible_role: classes.append("divider")
                if label == "On-Call": classes.append("oncall-row")
                class_str = f"class='{' '.join(classes)}'" if classes else ""
                
                role_bg = ROLE_COLORS.get(label, "#ffffff")
                style_role = f"background-color: {role_bg};" if label != "On-Call" else ""
                
                h = f"<tr {class_str}><td class='col-role' style='{style_role}'>{label}<br><span class='time-label'>{time_str}</span></td>"
                val_display = ", ".join(name_val) if isinstance(name_val, list) else str(name_val)
                if not val_display: val_display = "VACANT"
                
                style_name = f"background-color: {role_bg}; color: #333;"
                if label == "On-Call": style_name = "background-color: #d63031; color: white; font-weight: bold; border-color: #d63031;"
                if "VACANT" in val_display: style_name = "background-color: #ff0000; color: white; font-weight: bold; font-size: 14px;"

                h += f"<td class='col-names' style='{style_name}'>{val_display}</td>"
                h += get_day_cells(label, name_val)
                if first_row: h += f"<td rowspan='{rowspan}' class='col-week'>{wk}</td>"; first_row = False
                h += "</tr>"
                return h

            if show_early: html += render_row("Early", s.get('early', 'VACANT'), isinstance(s.get('early'), list), f"{times['early_s']}-{times['early_e']}")
            if show_central: html += render_row("Central", s.get('central', []), True, f"{times['central_s']}-{times['central_e']}")
            if show_late: html += render_row("Late", s.get('late', 'VACANT'), isinstance(s.get('late'), list), f"{times['late_s']}-{times['late_e']}")
            if show_weekend: html += render_row("Weekend", s.get('weekend', 'VACANT'), isinstance(s.get('weekend'), list), f"{times['weekend_s']}-{times['weekend_e']}")
            if show_oncall: html += render_row("On-Call", s.get('oncall', 'VACANT'), False, f"{times['oncall_s']}-{times['oncall_e']}")

        html += "</table>"
        if month_absences:
            html += """<div class="absence-section"><div class="absence-title">Notes / Absences:</div>"""
            for rec in month_absences: html += f"""<div class="absence-item"><b>{rec['name']}</b>: {rec['start']} to {rec['end']} ({rec['reason']})</div>"""
            html += "</div>"
        html += "</div>" 
    html += "</div></body></html>"
    
    with open(output_path, "w", encoding="utf-8") as f: f.write(html)
    return output_path