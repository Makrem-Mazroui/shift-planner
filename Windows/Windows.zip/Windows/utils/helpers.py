from datetime import datetime

def try_parse_date(date_str):
    """Attempts to parse a date string from various formats."""
    if not date_str:
        return None
    formats = ["%d%b%Y", "%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y", "%d.%m.%Y"]
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None