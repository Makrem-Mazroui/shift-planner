import tkinter as tk
from tkinter import messagebox, simpledialog, filedialog
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
import os
import json
import shutil
import glob
import webbrowser
import platform
from datetime import datetime, timedelta

# --- PROJECT IMPORTS ---
from config import TEAMS_DIR, BASE_DIR
from core.license import LicenseManager
from core.storage import load_members, save_members, load_schedule, save_schedule
from core.holidays import get_holidays_range
from core.mailer import OutlookMailer
from utils.exporters import generate_ics_content, render_html
from utils.helpers import try_parse_date

# --- CUSTOM SCROLLABLE FRAME ---
class ScrollableFrame(ttk.Frame):
    def __init__(self, container, *args, **kwargs):
        super().__init__(container, *args, **kwargs)
        self.canvas = tk.Canvas(self, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.scrollable_window = ttk.Frame(self.canvas)

        self.scrollable_window.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )

        self.canvas_window = self.canvas.create_window((0, 0), window=self.scrollable_window, anchor="nw")
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        self.bind_scroll(self.canvas)
        self.bind_scroll(self.scrollable_window)

    def _on_canvas_configure(self, event):
        self.canvas.itemconfig(self.canvas_window, width=event.width)

    def bind_scroll(self, widget):
        widget.bind("<Enter>", self._bound_to_mousewheel)
        widget.bind("<Leave>", self._unbound_to_mousewheel)

    def _bound_to_mousewheel(self, event):
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        self.canvas.bind_all("<Button-4>", self._on_mousewheel)
        self.canvas.bind_all("<Button-5>", self._on_mousewheel)

    def _unbound_to_mousewheel(self, event):
        self.canvas.unbind_all("<MouseWheel>")
        self.canvas.unbind_all("<Button-4>")
        self.canvas.unbind_all("<Button-5>")

    def _on_mousewheel(self, event):
        if platform.system() == "Darwin":
            delta = -1 * event.delta
        else:
            delta = int(-1 * (event.delta / 120))
        self.canvas.yview_scroll(delta, "units")

class ShiftPlannerApp(ttk.Window):
    def __init__(self):
        super().__init__(themename="cosmo")
        self.geometry("1200x950")
        self.title("PyDuty Pro V2")
        
        # 1. Load Saved Theme Preference using BASE_DIR
        self.settings_file = os.path.join(BASE_DIR, "settings.json")
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, "r") as f:
                    data = json.load(f)
                    saved_theme = data.get("theme", "cosmo")
                    self.style.theme_use(saved_theme)
            except:
                pass

        # --- LICENSE CHECK ---
        self.license_valid, self.license_msg, self.license_exp = LicenseManager.verify_license()
        
        # --- TEAM STATE ---
        self.current_team_name = None
        self.current_team_path = None
        self.current_files = {}
        self.members = []
        self.is_archive_mode = False

        # --- UI LAYOUT ---
        self.create_header()
        self.create_main_tabs()
        self.create_footer()

        # --- INITIAL STATE ---
        self.toggle_work_tabs(False)

        # --- LICENSE ENFORCEMENT ---
        if not self.license_valid:
            self.lock_features_license()
            self.show_license_warning()

    def create_header(self):
        """Creates the top dashboard header."""
        header_frame = ttk.Frame(self, bootstyle="primary", padding=15)
        header_frame.pack(fill=X)

        # App Title
        title_lbl = ttk.Label(
            header_frame,
            text="PyDuty Pro V2",
            font=("Helvetica", 16, "bold"),
            bootstyle="inverse-primary"
        )
        title_lbl.pack(side=LEFT)

        # --- LICENSE STATUS LOGIC ---
        if self.license_valid and self.license_exp:
            try:
                # Calculate days left
                exp_date = datetime.strptime(self.license_exp, "%Y-%m-%d")
                days_left = (exp_date - datetime.now()).days + 1 # +1 to include today
                
                if days_left > 0:
                    lic_text = f"LICENSE: ACTIVE ({days_left} Days)"
                    lic_style = "success"
                else:
                    lic_text = "LICENSE: EXPIRED"
                    lic_style = "danger"
            except:
                # Fallback if date format is weird
                lic_text = f"LICENSE: ACTIVE ({self.license_exp})"
                lic_style = "success"
        else:
            lic_text = f"LICENSE: {self.license_msg.upper()}"
            lic_style = "danger"
        
        # Right Side Items (Packed Right-to-Left)
        
        # 1. License Button
        ttk.Button(
            header_frame,
            text=lic_text,
            bootstyle=lic_style,
            command=self.open_activation_window,
            width=30
        ).pack(side=RIGHT, padx=5)

        # 2. Theme Selector
        theme_values = ["cosmo", "flatly", "journal", "litera", "lumen", "minty", "pulse", "sandstone", "united", "yeti", "superhero", "darkly", "solar", "cyborg", "vapor"]
        self.combo_theme = ttk.Combobox(header_frame, values=theme_values, state="readonly", width=10)
        
        # Set to the ACTUAL current theme
        self.combo_theme.set(self.style.theme.name)
        
        self.combo_theme.pack(side=RIGHT, padx=5)
        self.combo_theme.bind("<<ComboboxSelected>>", self.change_theme)
        
        ttk.Label(header_frame, text="Theme:", bootstyle="inverse-primary").pack(side=RIGHT, padx=(10, 2))

        # 3. Team Indicator
        self.lbl_current_team = ttk.Label(
            header_frame,
            text="NO TEAM LOADED",
            font=("Helvetica", 12),
            bootstyle="inverse-primary"
        )
        self.lbl_current_team.pack(side=RIGHT, padx=20)

    def change_theme(self, event):
        """Switches the application theme dynamically and saves preference."""
        new_theme = self.combo_theme.get()
        
        # 1. Save preference using BASE_DIR
        try:
            with open(self.settings_file, "w") as f:
                json.dump({"theme": new_theme}, f)
        except Exception as e:
            print(f"Error saving theme: {e}")

        # 2. Apply theme
        try:
            self.style.theme_use(new_theme)
        except tk.TclError:
            pass

    def create_main_tabs(self):
        self.notebook = ttk.Notebook(self, bootstyle="primary")
        self.notebook.pack(expand=True, fill=BOTH, padx=20, pady=20)
        
        self.tab_teams = ttk.Frame(self.notebook, padding=20)
        self.tab_members = ttk.Frame(self.notebook, padding=20)
        self.tab_gen = ttk.Frame(self.notebook, padding=20)
        self.tab_swap = ttk.Frame(self.notebook, padding=20)
        self.tab_stats = ttk.Frame(self.notebook, padding=20)
        
        self.notebook.add(self.tab_teams, text="1. Teams")
        self.notebook.add(self.tab_members, text="2. Members")
        self.notebook.add(self.tab_gen, text="3. Generate Plan")
        self.notebook.add(self.tab_swap, text="4. Swap / Edit")
        self.notebook.add(self.tab_stats, text="5. Skill Matrix & Stats")
        
        self.setup_teams_tab()
        self.setup_members_tab()
        self.setup_generate_tab()
        self.setup_swap_tab()
        self.setup_stats_tab()

    def create_footer(self):
        footer = ttk.Frame(self, padding=5)
        footer.pack(side=BOTTOM, fill=X)
        
        # Left side: Copyright/Tool Name
        ttk.Label(footer, text="PyDuty Pro V2", font=("Arial", 8, "bold"), foreground="gray").pack(side=LEFT, padx=10)
        
        # Right side: Version & Developer Credit
        ttk.Label(footer, text="Developer: Makrem Mazroui | E-mail: makremmazroui@gmail.com", font=("Arial", 8), foreground="gray").pack(side=RIGHT, padx=10)

    # --- TAB 1: TEAMS MANAGER ---
    def setup_teams_tab(self):
        container = ttk.Frame(self.tab_teams)
        container.pack(fill=BOTH, expand=True)
        left_panel = ttk.Labelframe(container, text="Available Teams", padding=15, bootstyle="info")
        left_panel.pack(side=LEFT, fill=BOTH, expand=True, padx=(0, 10))
        self.lst_teams = tk.Listbox(left_panel, font=("Segoe UI", 12), bd=0, highlightthickness=0, activestyle="none")
        self.lst_teams.pack(fill=BOTH, expand=True, pady=10)
        self.refresh_teams_list()
        right_panel = ttk.Frame(container)
        right_panel.pack(side=RIGHT, fill=Y, padx=10)
        ttk.Label(right_panel, text="Actions", font=("Segoe UI", 12, "bold")).pack(pady=(0, 10))
        ttk.Button(right_panel, text="LOAD TEAM", command=self.load_selected_team, bootstyle="success", width=20).pack(pady=5)
        ttk.Separator(right_panel).pack(fill=X, pady=15)
        ttk.Button(right_panel, text="Create New Team", command=self.create_team, bootstyle="primary-outline", width=20).pack(pady=5)
        ttk.Button(right_panel, text="Delete Team", command=self.delete_team, bootstyle="danger-outline", width=20).pack(pady=5)

    def refresh_teams_list(self):
        self.lst_teams.delete(0, tk.END)
        if os.path.exists(TEAMS_DIR):
            for d in sorted([d for d in os.listdir(TEAMS_DIR) if os.path.isdir(os.path.join(TEAMS_DIR, d))]):
                self.lst_teams.insert(tk.END, d)

    def create_team(self):
        # --- Custom Themed Dialog Start ---
        popup = ttk.Toplevel(self)
        popup.title("New Team")
        popup.geometry("350x180")
        
        # Center the popup relative to the main window
        try:
            x = self.winfo_x() + (self.winfo_width() // 2) - 175
            y = self.winfo_y() + (self.winfo_height() // 2) - 90
            popup.geometry(f"+{x}+{y}")
        except: pass # Fallback if geometry calc fails

        ttk.Label(popup, text="Enter Team Name:", font=("Segoe UI", 11, "bold")).pack(pady=(20, 5))
        
        entry = ttk.Entry(popup, width=30)
        entry.pack(pady=5, padx=20)
        entry.focus_set()
        
        # Variable to capture input
        result = {"text": None}
        
        def on_ok(event=None):
            result["text"] = entry.get()
            popup.destroy()
            
        def on_cancel():
            popup.destroy()
            
        btn_frame = ttk.Frame(popup)
        btn_frame.pack(pady=15)
        
        # Themed Buttons (Readable!)
        ttk.Button(btn_frame, text="OK", command=on_ok, bootstyle="success", width=10).pack(side=LEFT, padx=5)
        ttk.Button(btn_frame, text="Cancel", command=on_cancel, bootstyle="secondary", width=10).pack(side=LEFT, padx=5)
        
        popup.bind("<Return>", on_ok)
        popup.transient(self)
        popup.grab_set() # Make modal
        self.wait_window(popup) # Wait for close
        
        name = result["text"]
        # --- Custom Themed Dialog End ---

        if not name: return
        
        # Existing Logic
        safe_name = "".join([c for c in name if c.isalnum() or c in (' ', '_', '-')]).strip()
        path = os.path.join(TEAMS_DIR, safe_name)
        if os.path.exists(path): 
            messagebox.showerror("Error", "Team exists!")
        else:
            os.makedirs(path)
            self.refresh_teams_list()
            try:
                # Auto-select the new team
                all_teams = self.lst_teams.get(0, tk.END)
                if safe_name in all_teams:
                    idx = all_teams.index(safe_name)
                    self.lst_teams.selection_clear(0, tk.END)
                    self.lst_teams.selection_set(idx)
                    self.load_selected_team()
                messagebox.showinfo("Success", f"Team '{safe_name}' created and loaded.")
            except: pass

    def delete_team(self):
        sel = self.lst_teams.curselection()
        if not sel: return
        name = self.lst_teams.get(sel[0])
        if messagebox.askyesno("Confirm", f"Delete '{name}'?"):
            try:
                shutil.rmtree(os.path.join(TEAMS_DIR, name))
                self.refresh_teams_list()
                if self.current_team_name == name:
                    self.current_team_name = None
                    self.lbl_current_team.config(text="NO TEAM LOADED")
                    self.toggle_work_tabs(False)
            except Exception as e: messagebox.showerror("Error", str(e))

    def load_selected_team(self):
        sel = self.lst_teams.curselection()
        if not sel: return
        name = self.lst_teams.get(sel[0])
        self.current_team_name = name
        self.current_team_path = os.path.join(TEAMS_DIR, name)
        self.current_files = {
            "members": os.path.join(self.current_team_path, "members.json"),
            "data": os.path.join(self.current_team_path, "schedule_data.json"),
            "html": os.path.join(self.current_team_path, f"shift_plan_{name}.html")
        }
        self.members = load_members(self.current_files["members"])
        self.is_archive_mode = False
        self.refresh_member_list()
        self.load_initial_config()
        self.lbl_current_team.config(text=f"TEAM: {name.upper()}", bootstyle="inverse-primary")
        self.toggle_work_tabs(True)
        self.notebook.select(1)

    def toggle_work_tabs(self, enabled):
        state = "normal" if enabled else "disabled"
        for i in range(1, 5): self.notebook.tab(i, state=state)

    # --- TAB 2: MEMBERS ---
    def setup_members_tab(self):
        paned = ttk.Panedwindow(self.tab_members, orient="horizontal")
        paned.pack(fill=BOTH, expand=True)
        left_frame = ttk.Labelframe(paned, text="Team Roster", padding=10, bootstyle="info")
        paned.add(left_frame, weight=1)
        self.lst_members = tk.Listbox(left_frame, height=15, font=("Segoe UI", 11), bd=0)
        self.lst_members.pack(fill=BOTH, expand=True, pady=5)
        self.lst_members.bind('<<ListboxSelect>>', self.on_member_select)
        
        right_wrapper = ttk.Frame(paned)
        paned.add(right_wrapper, weight=2)
        right_frame = ScrollableFrame(right_wrapper)
        right_frame.pack(fill=BOTH, expand=True)
        content = right_frame.scrollable_window

        ttk.Label(content, text="MEMBER PROFILE", font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(0,10))
        form_grid = ttk.Frame(content)
        form_grid.pack(fill=X)
        ttk.Label(form_grid, text="Full Name:").grid(row=0, column=0, sticky="w", pady=5)
        self.entry_name = ttk.Entry(form_grid, width=30); self.entry_name.grid(row=0, column=1, padx=10, sticky="w")
        ttk.Label(form_grid, text="Email:").grid(row=1, column=0, sticky="w", pady=5)
        self.entry_email = ttk.Entry(form_grid, width=30); self.entry_email.grid(row=1, column=1, padx=10, sticky="w")

        # Preferences
        ttk.Separator(content).pack(fill=X, pady=20)
        ttk.Label(content, text="SHIFT PREFERENCES & ROLE", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0,10))
        pref_grid = ttk.Frame(content); pref_grid.pack(fill=X)
        ttk.Label(pref_grid, text="Preferred Shift:").grid(row=0, column=0, sticky="w", pady=5)
        self.combo_pref = ttk.Combobox(pref_grid, values=["Any", "Early Only", "Central Only", "Late Only", "Weekend"], state="readonly", width=28)
        self.combo_pref.set("Any"); self.combo_pref.grid(row=0, column=1, padx=10, sticky="w")
        ttk.Label(pref_grid, text="Seniority Level:").grid(row=1, column=0, sticky="w", pady=5)
        self.combo_level = ttk.Combobox(pref_grid, values=["Senior", "Junior"], state="readonly", width=28)
        self.combo_level.set("Senior"); self.combo_level.grid(row=1, column=1, padx=10, sticky="w")
        ttk.Label(pref_grid, text="On-Call Eligible:").grid(row=2, column=0, sticky="w", pady=5)
        self.var_oncall = tk.BooleanVar(value=True)
        ttk.Checkbutton(pref_grid, variable=self.var_oncall, bootstyle="round-toggle").grid(row=2, column=1, padx=10, sticky="w")

        ttk.Separator(content).pack(fill=X, pady=20)
        ttk.Label(content, text="SKILL REPERTOIRE", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.skill_container = ttk.Frame(content); self.skill_container.pack(fill=X, pady=10)
        
        skill_add_frame = ttk.Frame(content); skill_add_frame.pack(fill=X, pady=5)
        self.entry_new_skill = ttk.Entry(skill_add_frame, width=20); self.entry_new_skill.pack(side=LEFT, padx=(0,5))
        ttk.Button(skill_add_frame, text="Add Skill", command=self.add_skill_to_member, bootstyle="info-outline").pack(side=LEFT)

        btn_frame = ttk.Frame(content); btn_frame.pack(fill=X, pady=30)
        ttk.Button(btn_frame, text="Save Member Data", command=self.add_member, bootstyle="success").pack(side=LEFT, padx=5)
        ttk.Button(btn_frame, text="Remove Member", command=self.remove_member, bootstyle="danger").pack(side=RIGHT, padx=5)

    def refresh_member_list(self):
        self.lst_members.delete(0, tk.END)
        for m in self.members: self.lst_members.insert(tk.END, m["name"])

    def on_member_select(self, event):
        sel = self.lst_members.curselection()
        if sel:
            m = self.members[sel[0]]
            self.entry_name.delete(0, tk.END); self.entry_name.insert(0, m["name"])
            self.entry_email.delete(0, tk.END); self.entry_email.insert(0, m.get("email", ""))
            self.combo_pref.set(m.get("pref", "Any"))
            self.combo_level.set(m.get("level", "Senior"))
            self.var_oncall.set(m.get("oncall", True))
            self.refresh_skill_list_ui(m)

    def refresh_skill_list_ui(self, member):
        for w in self.skill_container.winfo_children(): w.destroy()
        if not member.get("skills"):
            ttk.Label(self.skill_container, text="No skills recorded.", font=("Arial", 9, "italic"), foreground="gray").pack(anchor="w")
            return
        for skill, val in member["skills"].items():
            row = ttk.Frame(self.skill_container); row.pack(fill=X, pady=2)
            ttk.Label(row, text=skill, width=15).pack(side=LEFT)
            var = tk.IntVar(value=val)
            ttk.Scale(row, from_=1, to=5, variable=var, orient=HORIZONTAL, length=100, command=lambda v_str, s=skill, v_var=var: self.update_skill_val(v_str, member, s, v_var)).pack(side=LEFT, padx=10)
            ttk.Label(row, textvariable=var).pack(side=LEFT, padx=5)
            ttk.Button(row, text="×", command=lambda s=skill: self.remove_skill_from_member(member, s), bootstyle="danger-link").pack(side=RIGHT)

    def update_skill_val(self, val_str, member, skill, var):
        new_val = round(float(val_str))
        var.set(new_val)
        member["skills"][skill] = new_val
        save_members(self.members, self.current_files["members"])

    def add_skill_to_member(self):
        skill_name = self.entry_new_skill.get().strip()
        if not skill_name: return
        sel = self.lst_members.curselection()
        member = None
        if sel: member = self.members[sel[0]]
        else:
            name = self.entry_name.get().strip()
            if name:
                member = next((m for m in self.members if m["name"] == name), None)
                if not member:
                    self.add_member()
                    member = next((m for m in self.members if m["name"] == name), None)
                    if member:
                        try:
                            idx = [m["name"] for m in self.members].index(name)
                            self.lst_members.selection_set(idx)
                        except: pass
            else:
                messagebox.showwarning("Selection Required", "Please select a member or enter a name.")
                return
        if member:
            if "skills" not in member: member["skills"] = {}
            member["skills"][skill_name] = 3
            self.refresh_skill_list_ui(member)
            self.entry_new_skill.delete(0, tk.END)
            save_members(self.members, self.current_files["members"])

    def remove_skill_from_member(self, member, skill):
        if skill in member["skills"]:
            del member["skills"][skill]
            self.refresh_skill_list_ui(member)
            save_members(self.members, self.current_files["members"])

    def add_member(self):
        if not self.current_team_name: return
        name = self.entry_name.get().strip()
        email = self.entry_email.get().strip()
        pref = self.combo_pref.get()
        level = self.combo_level.get()
        oncall = self.var_oncall.get()
        if name:
            existing = next((x for x in self.members if x["name"] == name), None)
            if existing:
                existing["email"] = email
                existing["pref"] = pref
                existing["level"] = level
                existing["oncall"] = oncall
                messagebox.showinfo("Updated", f"Updated details for {name}")
            else:
                self.members.append({"name": name, "email": email, "pref": pref, "oncall": oncall, "level": level, "skills": {}})
            save_members(self.members, self.current_files["members"])
            self.refresh_member_list()
            self.entry_name.delete(0, tk.END); self.entry_email.delete(0, tk.END)
            self.combo_pref.set("Any"); self.combo_level.set("Senior"); self.var_oncall.set(True)
            for w in self.skill_container.winfo_children(): w.destroy()
            ttk.Label(self.skill_container, text="Select a member to view skills.", font=("Arial", 9, "italic"), foreground="gray").pack(anchor="w")

    def rename_member(self): self.add_member()

    def remove_member(self):
        if not self.current_team_name: return
        sel = self.lst_members.curselection()
        if not sel: return
        if messagebox.askyesno("Confirm", "Remove this member?"):
            self.members.pop(sel[0])
            save_members(self.members, self.current_files["members"])
            self.refresh_member_list()
            self.entry_name.delete(0, tk.END); self.entry_email.delete(0, tk.END)

    # --- TAB 3: GENERATE ---
    def setup_generate_tab(self):
        main_scroll = ScrollableFrame(self.tab_gen)
        main_scroll.pack(fill=BOTH, expand=True)
        content = main_scroll.scrollable_window

        config_frame = ttk.Labelframe(content, text="1. Configuration", padding=15, bootstyle="primary")
        config_frame.pack(fill=X, padx=10, pady=5)
        
        ttk.Label(config_frame, text="Plan Type:", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w", pady=5)
        self.var_type = tk.StringVar(value="both")
        type_frame = ttk.Frame(config_frame)
        type_frame.grid(row=0, column=1, sticky="w", padx=10)
        for t in ["both", "shift-plan", "oncall"]: 
            ttk.Radiobutton(type_frame, text=t.capitalize(), variable=self.var_type, value=t, command=self.update_visibility).pack(side=LEFT, padx=5)

        self.lbl_combo = ttk.Label(config_frame, text="Shift Combo:", font=("Segoe UI", 10, "bold"))
        self.lbl_combo.grid(row=1, column=0, sticky="w", pady=5)
        
        self.combo_shifts = ttk.Combobox(config_frame, state="readonly", width=30)
        self.combo_shifts['values'] = ["Early + Central + Late", "Early + Central + Late + Weekend", "Early + Central", "Early + Late", "Central + Late", "Central Only"]
        self.combo_shifts.current(0)
        self.combo_shifts.grid(row=1, column=1, sticky="w", padx=10)
        self.combo_shifts.bind("<<ComboboxSelected>>", lambda e: self.update_visibility())

        toggle_frame = ttk.Frame(config_frame)
        toggle_frame.grid(row=1, column=2, sticky="w", padx=20)
        self.var_anti_zombie = tk.BooleanVar(value=False)
        self.var_seniority = tk.BooleanVar(value=False)

        ttk.Label(config_frame, text="Start Date Monday:", font=("Segoe UI", 10, "bold")).grid(row=2, column=0, sticky="w", pady=5)
        self.entry_date = ttk.Entry(config_frame, width=15)
        self.entry_date.insert(0, datetime.now().strftime("%d%b%Y"))
        self.entry_date.grid(row=2, column=1, sticky="w", padx=10)
        
        dur_frame = ttk.Frame(config_frame)
        dur_frame.grid(row=2, column=2, sticky="w", padx=20)
        ttk.Label(dur_frame, text="Months:", font=("Segoe UI", 10, "bold")).pack(side=LEFT)
        self.spin_duration = ttk.Spinbox(dur_frame, from_=1, to=12, width=5)
        self.spin_duration.set(6)
        self.spin_duration.pack(side=LEFT, padx=5)
        
        ttk.Label(dur_frame, text="Country:", font=("Segoe UI", 10, "bold")).pack(side=LEFT, padx=15)
        self.combo_country = ttk.Combobox(dur_frame, state="readonly", width=5, values=["CZ", "SK", "DE", "UK", "US", "FR", "PL"])
        self.combo_country.set("CZ")
        self.combo_country.pack(side=LEFT, padx=5)

        self.comp_frame = ttk.Labelframe(content, text="Weekend Worker Comp Off", padding=10, bootstyle="info")
        ttk.Label(self.comp_frame, text="Day 1:").pack(side=LEFT)
        self.combo_comp1 = ttk.Combobox(self.comp_frame, state="readonly", width=12, values=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]); self.combo_comp1.set("Thursday"); self.combo_comp1.pack(side=LEFT, padx=5)
        ttk.Label(self.comp_frame, text="Day 2:").pack(side=LEFT, padx=10)
        self.combo_comp2 = ttk.Combobox(self.comp_frame, state="readonly", width=12, values=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]); self.combo_comp2.set("Friday"); self.combo_comp2.pack(side=LEFT, padx=5)

        bottom_frame = ttk.Frame(content)
        bottom_frame.pack(fill=X, padx=10, pady=5)
        
        self.staff_frame = ttk.Labelframe(bottom_frame, text="2. Staffing Counts", padding=10, bootstyle="warning")
        self.staff_frame.pack(fill=X, padx=10, pady=5)
        self.lbl_early = ttk.Label(self.staff_frame, text="Early Shift Count:")
        self.lbl_early.pack(side=LEFT)
        self.spin_early_count = ttk.Spinbox(self.staff_frame, from_=0, to=10, width=5)
        self.spin_early_count.set(1)
        self.spin_early_count.pack(side=LEFT, padx=5)
        self.lbl_late = ttk.Label(self.staff_frame, text="Late Shift Count:")
        self.lbl_late.pack(side=LEFT, padx=20)
        self.spin_late_count = ttk.Spinbox(self.staff_frame, from_=0, to=10, width=5)
        self.spin_late_count.set(1)
        self.spin_late_count.pack(side=LEFT, padx=5)

        self.time_frame = ttk.Labelframe(content, text="3. Timings", padding=10, bootstyle="secondary")
        self.time_frame.pack(fill=X, padx=10, pady=5)
        self.time_rows = {}
        def add_time_row(key, c_idx, label, def_s, def_e):
            f = ttk.Frame(self.time_frame); f.grid(row=0, column=c_idx, padx=10)
            ttk.Label(f, text=label, font=("Segoe UI", 9, "bold")).pack(side=LEFT)
            e_s = ttk.Entry(f, width=6); e_s.insert(0, def_s); e_s.pack(side=LEFT, padx=2)
            ttk.Label(f, text="-").pack(side=LEFT)
            e_e = ttk.Entry(f, width=6); e_e.insert(0, def_e); e_e.pack(side=LEFT, padx=2); self.time_rows[key] = f
            return e_s, e_e
        self.t_early_s, self.t_early_e = add_time_row("early", 0, "Early", "07:00", "15:30")
        self.t_central_s, self.t_central_e = add_time_row("central", 1, "Central", "09:00", "17:30")
        self.t_late_s, self.t_late_e = add_time_row("late", 2, "Late", "10:30", "19:00")
        self.t_weekend_s, self.t_weekend_e = add_time_row("weekend", 3, "Weekend", "09:00", "17:00")
        self.t_oncall_s, self.t_oncall_e = add_time_row("oncall", 4, "On-Call", "17:30", "08:00")

        btn_area = ttk.Frame(content, padding=10)
        btn_area.pack(fill=X, pady=10)
        ttk.Button(btn_area, text="GENERATE DASHBOARD", command=self.generate_plan, bootstyle="success", width=22).pack(side=LEFT, padx=5)
        ttk.Button(btn_area, text="SEND VIA OUTLOOK", command=self.open_email_window, bootstyle="primary", width=20).pack(side=LEFT, padx=5)
        ttk.Separator(btn_area, orient=VERTICAL).pack(side=LEFT, fill=Y, padx=10)
        ttk.Button(btn_area, text="View Plan", command=self.view_current_plan, bootstyle="info-outline").pack(side=LEFT, padx=2)
        ttk.Button(btn_area, text="Archive", command=self.archive_current_plan, bootstyle="warning-outline").pack(side=LEFT, padx=2)
        ttk.Button(btn_area, text="History", command=self.open_archive_manager, bootstyle="secondary-outline").pack(side=LEFT, padx=2)
        
        self.update_visibility()

    def update_visibility(self):
        mode = self.var_type.get()
        combo = self.combo_shifts.get()
        
        if mode == "oncall":
            self.lbl_combo.grid_remove()
            self.combo_shifts.grid_remove()
            self.staff_frame.pack_forget()
        else:
            self.lbl_combo.grid()
            self.combo_shifts.grid()
            self.staff_frame.pack(fill=X, pady=5)

        needs_early = "Early" in combo and mode != "oncall"
        needs_late = "Late" in combo and mode != "oncall"
        needs_weekend = "Weekend" in combo and mode != "oncall"
        
        if needs_weekend: self.comp_frame.pack(fill=X, pady=5)
        else: self.comp_frame.pack_forget()

        def toggle(w, show, **kw):
            if show: w.pack(**kw)
            else: w.pack_forget()
        toggle(self.lbl_early, needs_early, side=LEFT)
        toggle(self.spin_early_count, needs_early, side=LEFT, padx=5)
        toggle(self.lbl_late, needs_late, side=LEFT)
        toggle(self.spin_late_count, needs_late, side=LEFT, padx=5)
        
        for k in ["early", "central", "late", "weekend", "oncall"]:
            if (k == "early" and needs_early) or (k == "central" and "Central" in combo) or \
               (k == "late" and needs_late) or (k == "weekend" and needs_weekend) or \
               (k == "oncall" and mode in ["both", "oncall"]):
                self.time_rows[k].grid()
            else: self.time_rows[k].grid_remove()

    def generate_plan(self):
        if not self.current_team_name: return
        
        # 1. Validation
        if len(self.members) < 2:
            messagebox.showwarning("Incomplete Team", "You need at least 2 members in the Roster to generate a plan.")
            return
        
        start = try_parse_date(self.entry_date.get())
        if not start:
            messagebox.showerror("Error", "Invalid Date Format. Use 01Feb2026.")
            return

        # 2. Dynamic Filename Update (e.g., shift_plan_2026.html)
        self.current_files["html"] = os.path.join(self.current_team_path, f"shift_plan_{start.year}.html")

        # 3. Setup Variables
        mos = int(self.spin_duration.get())
        pt = self.var_type.get()
        sc = self.combo_shifts.get()
        country = self.combo_country.get()
        
        day_map = {"Monday": 0, "Tuesday": 1, "Wednesday": 2, "Thursday": 3, "Friday": 4}
        comp = [day_map.get(self.combo_comp1.get(), 3), day_map.get(self.combo_comp2.get(), 4)]
        
        # Logic to force counts to 0 if not selected in Combo
        raw_ne = int(self.spin_early_count.get())
        raw_nl = int(self.spin_late_count.get())
        
        ne = raw_ne if "Early" in sc else 0
        nl = raw_nl if "Late" in sc else 0

        times = {k: getattr(self, f"t_{k}").get() for k in ["early_s","early_e","central_s","central_e","late_s","late_e","weekend_s","weekend_e","oncall_s","oncall_e"]}
        
        cutoff = start.replace(day=1)
        for _ in range(mos): cutoff = (cutoff + timedelta(days=32)).replace(day=1)
        
        holidays = get_holidays_range(start, cutoff, country)
        shifts = []
        curr = start
        week_idx = 0
        
        oc_pool = [m["name"] for m in self.members if m.get("oncall",True)]
        last_week_late_members = []

        # 4. Main Generation Loop
        while curr < cutoff:
            sd = {"week_num": curr.isocalendar()[1], "start": curr, "end": curr+timedelta(days=6)}
            
            if pt in ["oncall","both"] and oc_pool:
                sd["oncall"] = oc_pool[week_idx % len(oc_pool)]
            
            if pt in ["shift-plan","both"]:
                full = [m["name"] for m in self.members]
                cands = full[week_idx % len(full):] + full[:week_idx % len(full)]
                
                weekend_worker = cands[-1] if "Weekend" in sc else None
                if weekend_worker: sd["weekend"] = weekend_worker
                
                def assign_role(role_name, count_needed, candidates):
                    assigned, remaining = [], []
                    for p in candidates:
                        if p == weekend_worker:
                            remaining.append(p)
                            continue
                        if len(assigned) < count_needed:
                            m = next((x for x in self.members if x["name"] == p), None)
                            is_zombie = self.var_anti_zombie.get() and role_name == "early" and p in last_week_late_members
                            pref = m.get("pref", "Any") if m else "Any"
                            
                            if not is_zombie and (pref == "Any" or pref == f"{role_name.capitalize()} Only"):
                                assigned.append(p)
                            else:
                                remaining.append(p)
                        else:
                            remaining.append(p)
                            
                    # Fallback
                    if len(assigned) < count_needed:
                        fallback = remaining[:]
                        remaining = []
                        for p in fallback:
                            if p == weekend_worker: remaining.append(p); continue
                            if len(assigned) < count_needed: assigned.append(p)
                            else: remaining.append(p)
                    return assigned, remaining

                ae, rem = assign_role("early", ne, cands)
                al, rem = assign_role("late", nl, rem)
                
                sd["early"] = ae[0] if len(ae)==1 else (ae or "VACANT")
                sd["late"] = al[0] if len(al)==1 else (al or "VACANT")
                
                if "Central" in sc:
                    sd["central"] = rem

                # --- SENIORITY LOGIC ---
                if self.var_seniority.get():
                    for role in ['early', 'central', 'late']:
                        if role == "early" and ne == 0: continue
                        if role == "late" and nl == 0: continue
                        if role == "central" and "Central" not in sc: continue

                        assigned = sd.get(role)
                        if not assigned or assigned == "VACANT": continue
                        
                        assigned_list = assigned if isinstance(assigned, list) else [assigned]
                        
                        all_juniors = True
                        for p in assigned_list:
                            m_obj = next((x for x in self.members if x["name"] == p), None)
                            if m_obj and m_obj.get("level") == "Senior":
                                all_juniors = False
                                break
                        
                        if all_juniors:
                            swapped = False
                            for other_role in ['early', 'central', 'late']:
                                if other_role == role: continue
                                if other_role == "early" and ne == 0: continue
                                if other_role == "late" and nl == 0: continue
                                if other_role == "central" and "Central" not in sc: continue

                                other_val = sd.get(other_role)
                                if not other_val or other_val == "VACANT": continue
                                other_list = other_val if isinstance(other_val, list) else [other_val]
                                
                                for cand in other_list:
                                    cand_obj = next((x for x in self.members if x["name"] == cand), None)
                                    if cand_obj and cand_obj.get("level") == "Senior":
                                        junior_to_move = assigned_list[0]
                                        assigned_list[0] = cand
                                        
                                        if isinstance(other_val, list):
                                            idx = other_list.index(cand)
                                            other_list[idx] = junior_to_move
                                            sd[other_role] = other_list
                                        else:
                                            sd[other_role] = junior_to_move
                                        
                                        sd[role] = assigned_list if len(assigned_list) > 1 else assigned_list[0]
                                        swapped = True
                                        break
                                if swapped: break
                # -----------------------

                raw_late = sd.get("late", [])
                last_week_late_members = [x for x in (raw_late if isinstance(raw_late, list) else [raw_late]) if x != "VACANT"]

            shifts.append(sd)
            curr += timedelta(days=7)
            week_idx += 1

        # 5. Save & Render
        save_schedule(shifts, start.year, pt, sc, times, {"early":ne, "late":nl}, country, [], comp, self.current_files["data"])
        render_html(shifts, start.year, pt, sc, times, holidays, [], comp, self.current_files["html"])
        
        messagebox.showinfo("Success", f"Dashboard Generated for {self.current_team_name}\nFile: shift_plan_{start.year}.html")
        self.refresh_stats_table()

    # --- ARCHIVE FEATURES ---
    def view_current_plan(self):
        html_path = self.current_files.get("html")
        if html_path and os.path.exists(html_path):
            webbrowser.open('file://' + os.path.abspath(html_path))
        else:
            messagebox.showerror("Error", "No plan generated yet.")

    def archive_current_plan(self):
        if not self.current_team_name: return
        data_path = self.current_files.get("data")
        if not data_path or not os.path.exists(data_path):
            messagebox.showerror("Error", "No plan to archive.")
            return
            
        archive_dir = os.path.join(self.current_team_path, "archive")
        if not os.path.exists(archive_dir): os.makedirs(archive_dir)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = f"plan_{timestamp}"
        
        shutil.copy(data_path, os.path.join(archive_dir, f"{base_name}.json"))
        if os.path.exists(self.current_files["html"]):
            shutil.copy(self.current_files["html"], os.path.join(archive_dir, f"{base_name}.html"))
            
        messagebox.showinfo("Archived", f"Plan saved to archive as:\n{base_name}")

    def open_archive_manager(self):
        if not self.current_team_name: return
        archive_dir = os.path.join(self.current_team_path, "archive")
        if not os.path.exists(archive_dir): os.makedirs(archive_dir)
        
        win = ttk.Toplevel(self)
        win.title("Archive History")
        win.geometry("400x400")
        
        ttk.Label(win, text="Saved Plans", font=("bold", 12)).pack(pady=10)
        
        lst = tk.Listbox(win)
        lst.pack(fill=BOTH, expand=True, padx=10, pady=5)
        
        files = sorted(glob.glob(os.path.join(archive_dir, "*.json")), reverse=True)
        for f in files:
            lst.insert(tk.END, os.path.basename(f))
            
        def load_archive():
            sel = lst.curselection()
            if not sel: return
            fname = lst.get(sel[0])
            full_path = os.path.join(archive_dir, fname)
            
            data = load_schedule(full_path)
            if data:
                if messagebox.askyesno("Restore", "Load this archive? This will overwrite the current active plan."):
                    shutil.copy(full_path, self.current_files["data"])
                    html_name = fname.replace(".json", ".html")
                    html_src = os.path.join(archive_dir, html_name)
                    if os.path.exists(html_src):
                        shutil.copy(html_src, self.current_files["html"])
                    
                    self.load_initial_config()
                    self.lbl_current_team.config(text=f"TEAM: {self.current_team_name} (RESTORED)", bootstyle="warning-inverse")
                    messagebox.showinfo("Loaded", "Archive restored successfully.")
                    win.destroy()

        def delete_archive():
            sel = lst.curselection()
            if not sel: return
            fname = lst.get(sel[0])
            if messagebox.askyesno("Delete", f"Delete {fname}?"):
                os.remove(os.path.join(archive_dir, fname))
                html_name = fname.replace(".json", ".html")
                if os.path.exists(os.path.join(archive_dir, html_name)):
                    os.remove(os.path.join(archive_dir, html_name))
                lst.delete(sel[0])

        btn_f = ttk.Frame(win)
        btn_f.pack(fill=X, pady=10)
        ttk.Button(btn_f, text="Load / Restore", command=load_archive, bootstyle="warning").pack(side=LEFT, padx=10)
        ttk.Button(btn_f, text="Delete", command=delete_archive, bootstyle="danger").pack(side=RIGHT, padx=10)

    def open_email_window(self):
        if not self.current_team_name: return
        
        mailer = OutlookMailer()
        if not mailer.available:
            messagebox.showerror("Outlook Not Found", mailer.error_msg)
            return

        win = ttk.Toplevel(self)
        win.title("Outlook Dispatcher")
        win.geometry("600x550")
        
        ttk.Label(win, text="Send via Outlook Desktop App", font=("Segoe UI", 12, "bold"), bootstyle="primary").pack(pady=15)
        
        f = ttk.Frame(win, padding=10)
        f.pack(fill=X)
        ttk.Label(f, text="Message to Team:", font=("Segoe UI", 10)).pack(anchor="w")
        txt_msg = tk.Text(f, height=5, width=50, font=("Arial", 9)); txt_msg.pack(fill=X, pady=5)
        txt_msg.insert("1.0", f"Hello Team,\n\nPlease find attached the new shift plan for {self.current_team_name}.\n\nBest regards,")

        ttk.Label(win, text="Select Recipients:", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=10)
        
        recipients_frame = ScrollableFrame(win)
        recipients_frame.pack(fill=BOTH, expand=True, padx=10, pady=5)
        r_content = recipients_frame.scrollable_window

        self.email_vars = {}
        
        def toggle_all():
            val = all_var.get()
            for k, v in self.email_vars.items():
                v.set(val)

        all_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(r_content, text="Select All", variable=all_var, command=toggle_all, bootstyle="round-toggle").pack(anchor="w", pady=2)
        ttk.Separator(r_content).pack(fill=X, pady=5)

        for m in self.members:
            if m.get("email"):
                var = tk.BooleanVar(value=True)
                self.email_vars[m["email"]] = var
                ttk.Checkbutton(r_content, text=f"{m['name']} ({m['email']})", variable=var).pack(anchor="w")
            else:
                ttk.Label(r_content, text=f"{m['name']} (No Email)", foreground="gray").pack(anchor="w")

        def send():
            html_path = self.current_files.get("html")
            if not html_path or not os.path.exists(html_path):
                messagebox.showerror("Error", "No generated plan found. Generate the dashboard first.")
                return

            selected_emails = [email for email, var in self.email_vars.items() if var.get()]
            
            if not selected_emails:
                messagebox.showwarning("No Recipients", "Please select at least one member to email.")
                return

            count = 0
            errors = []
            
            prog_win = ttk.Toplevel(win)
            prog_win.geometry("250x100")
            ttk.Label(prog_win, text="Processing in Outlook...").pack(pady=30)
            prog_win.update()
            
            for m in self.members:
                email = m.get("email")
                if email and email in selected_emails:
                    success, msg = mailer.send_plan(
                        email, 
                        m["name"], 
                        f"Shift Plan - {self.current_team_name}", 
                        txt_msg.get("1.0", tk.END),
                        html_path
                    )
                    if success: count += 1
                    else: errors.append(f"{m['name']}: {msg}")
            
            prog_win.destroy()
            
            if errors:
                messagebox.showwarning("Partial Success", f"Sent: {count}\nFailed:\n" + "\n".join(errors))
            else:
                messagebox.showinfo("Success", f"Sent to {count} members via Outlook!")
            win.destroy()

        ttk.Button(win, text="SEND EMAILS NOW", command=send, bootstyle="primary").pack(pady=10, fill=X, padx=30)
        ttk.Label(win, text="* Outlook needs to be open and logged in.", font=("Arial", 8), foreground="gray").pack(pady=5)

    def export_calendars(self):
        if not self.current_team_name: return
        data = load_schedule(self.current_files.get("data"))
        if not data: return
        ef = os.path.join(self.current_team_path, "calendars_export")
        if not os.path.exists(ef): os.makedirs(ef)
        for m in self.members:
            txt = generate_ics_content(m["name"], data["shifts"], data["times"])
            sn = "".join([c for c in m["name"] if c.isalnum() or c in (' ', '_', '-')]).strip()
            with open(os.path.join(ef, f"{sn}.ics"), "w") as f: f.write(txt)
        messagebox.showinfo("Done", f"Exported to {ef}")

    # --- TAB 4: SWAP/EDIT ---
    # --- TAB 4: SWAP/EDIT ---
    def setup_swap_tab(self):
        self.swap_notebook = ttk.Notebook(self.tab_swap, bootstyle="info")
        self.swap_notebook.pack(fill=BOTH, expand=True, padx=10, pady=10)
        
        # --- Helper for placeholders ---
        def add_placeholder(entry, text):
            entry.insert(0, text)
            entry.configure(foreground="gray")
            def on_focus_in(event):
                if entry.get() == text:
                    entry.delete(0, "end")
                    entry.configure(foreground="black")
            def on_focus_out(event):
                if not entry.get():
                    entry.insert(0, text)
                    entry.configure(foreground="gray")
            entry.bind("<FocusIn>", on_focus_in)
            entry.bind("<FocusOut>", on_focus_out)
        # -------------------------------

        # Frame A: On-Call Swap
        frame_a = ttk.Frame(self.swap_notebook, padding=20)
        self.swap_notebook.add(frame_a, text="Swap On-Call")
        
        f_in = ttk.Frame(frame_a)
        f_in.pack(pady=20)
        ttk.Label(f_in, text="Week A:").grid(row=0, column=0, padx=5)
        self.sw_w1 = ttk.Entry(f_in, width=5)
        self.sw_w1.grid(row=0, column=1, padx=5)
        ttk.Label(f_in, text="Week B:").grid(row=0, column=2, padx=5)
        self.sw_w2 = ttk.Entry(f_in, width=5)
        self.sw_w2.grid(row=0, column=3, padx=5)
        ttk.Button(frame_a, text="Swap On-Call", command=self.do_swap_oncall, bootstyle="warning").pack(pady=10)
        
        # Frame B: Shift Swap
        frame_b = ttk.Frame(self.swap_notebook, padding=20)
        self.swap_notebook.add(frame_b, text="Swap Shifts")
        
        f_load = ttk.Frame(frame_b)
        f_load.pack(pady=20)
        ttk.Label(f_load, text="Week Num:").pack(side=LEFT, padx=5)
        self.entry_week_shift = ttk.Entry(f_load, width=5)
        self.entry_week_shift.pack(side=LEFT, padx=5)
        ttk.Button(f_load, text="Load Members", command=self.load_week_for_swap, bootstyle="info-outline").pack(side=LEFT)
        
        self.lbl_shift_info = ttk.Label(frame_b, text="Load a week first", foreground="gray")
        self.lbl_shift_info.pack(pady=5)
        
        f_sel = ttk.Frame(frame_b)
        f_sel.pack(pady=10)
        ttk.Label(f_sel, text="Person A:").grid(row=0, column=0, padx=5)
        self.combo_m1 = ttk.Combobox(f_sel, state="readonly")
        self.combo_m1.grid(row=0, column=1, padx=5)
        ttk.Label(f_sel, text="Person B:").grid(row=1, column=0, padx=5)
        self.combo_m2 = ttk.Combobox(f_sel, state="readonly")
        self.combo_m2.grid(row=1, column=1, padx=5)
        
        ttk.Button(frame_b, text="Swap Shifts", command=self.do_swap_same_week, bootstyle="warning").pack(pady=20)

        # Frame C: Absence
        frame_c = ttk.Frame(self.swap_notebook, padding=20)
        self.swap_notebook.add(frame_c, text="Absence")
        
        f_abs = ttk.Frame(frame_c)
        f_abs.pack(pady=20)
        ttk.Label(f_abs, text="Start Date Monday:").grid(row=0, column=0, padx=5)
        self.entry_abs_start = ttk.Entry(f_abs, width=12)
        add_placeholder(self.entry_abs_start, "DD-MM-YYYY") 
        self.entry_abs_start.grid(row=0, column=1, padx=5)
        
        ttk.Label(f_abs, text="End Date:").grid(row=0, column=2, padx=5)
        self.entry_abs_end = ttk.Entry(f_abs, width=12)
        add_placeholder(self.entry_abs_end, "DD-MM-YYYY") 
        self.entry_abs_end.grid(row=0, column=3, padx=5)
        
        ttk.Button(f_abs, text="Load Range", command=self.load_week_for_absence, bootstyle="info-outline").grid(row=0, column=4, padx=10)
        
        self.lbl_abs_info = ttk.Label(frame_c, text="Load a range first", foreground="gray")
        self.lbl_abs_info.pack(pady=5)
        
        f_proc = ttk.Frame(frame_c)
        f_proc.pack(pady=10)
        ttk.Label(f_proc, text="Absent Member:").grid(row=0, column=0, padx=5)
        self.combo_absent = ttk.Combobox(f_proc, width=15)
        self.combo_absent.grid(row=0, column=1, padx=5)
        
        ttk.Label(f_proc, text="Shift Replacement:").grid(row=1, column=0, padx=5)
        self.combo_repl_shift = ttk.Combobox(f_proc, width=15)
        self.combo_repl_shift.grid(row=1, column=1, padx=5)
        
        ttk.Label(f_proc, text="On-Call Replacement:").grid(row=2, column=0, padx=5)
        self.combo_repl_oncall = ttk.Combobox(f_proc, width=15)
        self.combo_repl_oncall.grid(row=2, column=1, padx=5)
        
        ttk.Label(f_proc, text="Reason:").grid(row=3, column=0, padx=5)
        self.entry_reason = ttk.Entry(f_proc, width=15)
        self.entry_reason.grid(row=3, column=1, padx=5)
        
        ttk.Button(frame_c, text="Process Leave", command=self.do_process_absence, bootstyle="danger").pack(pady=10)
        ttk.Button(frame_c, text="Clear All Absences", command=self.do_clear_absences, bootstyle="secondary-outline").pack(pady=5)

        # Frame D: Backfill
        frame_d = ttk.Frame(self.swap_notebook, padding=20)
        self.swap_notebook.add(frame_d, text="Backfill")
        
        f_bf = ttk.Frame(frame_d)
        f_bf.pack(pady=20)
        ttk.Label(f_bf, text="Start Date Monday:").grid(row=0, column=0, padx=5)
        self.entry_bf_start = ttk.Entry(f_bf, width=12)
        add_placeholder(self.entry_bf_start, "DD-MM-YYYY") # Fixed: Added placeholder
        self.entry_bf_start.grid(row=0, column=1, padx=5)
        
        ttk.Label(f_bf, text="End Date:").grid(row=0, column=2, padx=5)
        self.entry_bf_end = ttk.Entry(f_bf, width=12)
        add_placeholder(self.entry_bf_end, "DD-MM-YYYY") # Fixed: Added placeholder
        self.entry_bf_end.grid(row=0, column=3, padx=5)
        
        f_bf2 = ttk.Frame(frame_d)
        f_bf2.pack(pady=10)
        ttk.Label(f_bf2, text="Fill Shift With:").grid(row=0, column=0, padx=5)
        self.combo_bf_shift = ttk.Combobox(f_bf2, width=15, postcommand=self.refresh_backfill_combo)
        self.combo_bf_shift.grid(row=0, column=1, padx=5)
        
        ttk.Label(f_bf2, text="Fill On-Call With:").grid(row=1, column=0, padx=5)
        self.combo_bf_oncall = ttk.Combobox(f_bf2, width=15, postcommand=self.refresh_backfill_combo)
        self.combo_bf_oncall.grid(row=1, column=1, padx=5)
        
        ttk.Button(frame_d, text="Apply Changes", command=self.do_apply_backfill_changes, bootstyle="success").pack(pady=10)

    def refresh_backfill_combo(self):
        self.combo_bf_shift['values'] = [m["name"] for m in self.members]
        self.combo_bf_oncall['values'] = [m["name"] for m in self.members if m.get("oncall",True)]

    def do_swap_oncall(self):
        d = load_schedule(self.current_files["data"])
        if d:
            w1_val = self.sw_w1.get()
            w2_val = self.sw_w2.get()
            if not w1_val or not w2_val:
                messagebox.showerror("Error", "Please enter both Week numbers.")
                return
            try:
                w1, w2 = int(w1_val), int(w2_val)
                # Find the specific shift objects for these weeks
                s1 = next((s for s in d["shifts"] if s["week_num"]==w1), None)
                s2 = next((s for s in d["shifts"] if s["week_num"]==w2), None)
                
                if s1 and s2:
                    # Perform the swap
                    s1['oncall'], s2['oncall'] = s2['oncall'], s1['oncall']
                    
                    # Save JSON
                    save_schedule(d["shifts"], d["year"], d["plan_type"], d["shift_config"], d["times"], d["staffing"], d["country"], d["absences"], d["comp_days"], self.current_files["data"])
                    
                    # Force HTML Re-render so user sees the change
                    holidays = get_holidays_range(d["shifts"][0]["start"], d["shifts"][-1]["end"], d.get("country", "CZ"))
                    render_html(d["shifts"], d["year"], d["plan_type"], d["shift_config"], d["times"], holidays, d["absences"], d["comp_days"], self.current_files["html"])
                    
                    messagebox.showinfo("Done", f"Swapped On-Call for Week {w1} and {w2}. Check the dashboard.")
                    self.refresh_stats_table()
                else:
                    messagebox.showerror("Error", "Could not find shifts for those weeks. Check the dashboard for correct Week numbers.")
            except ValueError: 
                messagebox.showerror("Error", "Weeks must be numbers.")

    def load_week_for_swap(self):
        d = load_schedule(self.current_files["data"])
        if d:
            try:
                yr = d.get("year")
                s = next((x for x in d["shifts"] if x["week_num"]==int(self.entry_week_shift.get()) and x["start"].year == yr), None)
                if s: 
                    m = sorted(list(set([x for k in ['early','central','late','weekend','oncall'] for x in (s.get(k) if isinstance(s.get(k), list) else [s.get(k)]) if x and x!="VACANT"])))
                    self.combo_m1['values'], self.combo_m2['values'] = m, m
                    self.lbl_shift_info.config(text="Loaded", foreground="green")
            except: pass

    def do_swap_same_week(self):
        d = load_schedule(self.current_files["data"])
        try:
            w_val = self.entry_week_shift.get()
            if not w_val: return
            w = int(w_val)
            
            p1 = self.combo_m1.get()
            p2 = self.combo_m2.get()
            
            if not p1 or not p2:
                messagebox.showerror("Error", "Select two people to swap.")
                return

            # Find the week
            s = next((x for x in d["shifts"] if x["week_num"]==w), None)
            
            if s:
                # 1. PREFERENCE CHECK
                # Find what roles they are currently in
                role_p1 = None
                role_p2 = None
                
                # Only check working shifts, ignore oncall/weekend for preference logic
                for k in ["early", "central", "late"]:
                    val = s.get(k)
                    if isinstance(val, list):
                        if p1 in val: role_p1 = k
                        if p2 in val: role_p2 = k
                    elif val == p1: role_p1 = k
                    elif val == p2: role_p2 = k
                
                # Check if P1 is moving to P2's role (role_p2)
                if role_p2:
                    mem_p1 = next((m for m in self.members if m["name"] == p1), None)
                    if mem_p1:
                        pref = mem_p1.get("pref", "Any")
                        # If they have a specific preference AND it doesn't match the new role
                        if pref != "Any" and pref.lower() != f"{role_p2} only":
                             if not messagebox.askyesno("Preference Warning", f"{p1} prefers '{pref}', but you are moving them to '{role_p2.capitalize()}'.\n\nForce this swap?"):
                                 return

                # Check if P2 is moving to P1's role (role_p1)
                if role_p1:
                    mem_p2 = next((m for m in self.members if m["name"] == p2), None)
                    if mem_p2:
                        pref = mem_p2.get("pref", "Any")
                        if pref != "Any" and pref.lower() != f"{role_p1} only":
                             if not messagebox.askyesno("Preference Warning", f"{p2} prefers '{pref}', but you are moving them to '{role_p1.capitalize()}'.\n\nForce this swap?"):
                                 return

                # 2. PERFORM SWAP (Strictly excluding 'oncall')
                swap_keys = ["early", "central", "late", "weekend"]
                
                for k in swap_keys:
                    val = s.get(k)
                    if not val: continue
                    
                    if isinstance(val, list):
                        # If it's a list (like Central), replace the name inside the list
                        if p1 in val: 
                            idx = val.index(p1)
                            val[idx] = "TEMP_PLACEHOLDER" # Temp to avoid double swap in same list
                        if p2 in val:
                            idx = val.index(p2)
                            val[idx] = p1
                        
                        # Finish the temp swap
                        if "TEMP_PLACEHOLDER" in val:
                            idx = val.index("TEMP_PLACEHOLDER")
                            val[idx] = p2
                            
                        s[k] = val
                    else:
                        # Simple string swap
                        if val == p1: s[k] = p2
                        elif val == p2: s[k] = p1

                # Save and Render
                save_schedule(d["shifts"], d["year"], d["plan_type"], d["shift_config"], d["times"], d["staffing"], d["country"], d["absences"], d["comp_days"], self.current_files["data"])
                
                holidays = get_holidays_range(d["shifts"][0]["start"], d["shifts"][-1]["end"], d.get("country", "CZ"))
                render_html(d["shifts"], d["year"], d["plan_type"], d["shift_config"], d["times"], holidays, d["absences"], d["comp_days"], self.current_files["html"])
                
                self.refresh_stats_table()
                messagebox.showinfo("Success", f"Swapped {p1} and {p2} in Week {w}.")
                
        except ValueError:
            messagebox.showerror("Error", "Invalid Week Number")

    def load_week_for_absence(self):
        d = load_schedule(self.current_files["data"])
        if d:
            try:
                st = try_parse_date(self.entry_abs_start.get())
                en = try_parse_date(self.entry_abs_end.get())
                if not st or not en: return

                f = sorted(list(set([x for s in d["shifts"] if not (s['end'] < st or s['start'] > en) for k in ['early','central','late','oncall','weekend'] for x in (s.get(k) if isinstance(s.get(k), list) else [s.get(k)]) if x and x!="VACANT"])))
                self.combo_absent['values'] = f; self.combo_repl_shift['values'] = [m["name"] for m in self.members]; self.combo_repl_oncall['values'] = [m["name"] for m in self.members if m.get("oncall",True)]
                self.lbl_abs_info.config(text=f"Found {len(f)} members", foreground="green")
            except: pass

    def do_clear_absences(self):
        d = load_schedule(self.current_files["data"])
        if d and messagebox.askyesno("Confirm", "Clear ALL absences?"):
            d["absences"] = []
            save_schedule(d["shifts"], d["year"], d["plan_type"], d["shift_config"], d["times"], d["staffing"], d["country"], [], d["comp_days"], self.current_files["data"])
            
            holidays = get_holidays_range(d["shifts"][0]["start"], d["shifts"][-1]["end"], d.get("country", "CZ"))
            render_html(d["shifts"], d["year"], d["plan_type"], d["shift_config"], d["times"], holidays, [], d["comp_days"], self.current_files["html"])
            
            self.refresh_stats_table()

    def do_process_absence(self):
        d = load_schedule(self.current_files["data"])
        if d:
            try:
                st = try_parse_date(self.entry_abs_start.get())
                en = try_parse_date(self.entry_abs_end.get())
                ab, rs, ro = self.combo_absent.get(), self.combo_repl_shift.get(), self.combo_repl_oncall.get()
                
                if not st or not en: return

                u = 0
                for s in d["shifts"]:
                    if not (s['end'] < st or s['start'] > en):
                        for k in ['early','central','late','weekend']:
                            v = s.get(k)
                            if v:
                                if isinstance(v, list) and ab in v: v.remove(ab); v.append(rs or "VACANT"); s[k]=v; u+=1
                                elif v==ab: s[k]=rs or "VACANT"; u+=1
                        if s.get('oncall') == ab: s['oncall'] = ro or "VACANT"; u+=1
                if u:
                    d["absences"].append({"name": ab, "start": self.entry_abs_start.get(), "end": self.entry_abs_end.get(), "reason": self.entry_reason.get()})
                    
                    save_schedule(d["shifts"], d["year"], d["plan_type"], d["shift_config"], d["times"], d["staffing"], d["country"], d["absences"], d["comp_days"], self.current_files["data"])
                    
                    holidays = get_holidays_range(d["shifts"][0]["start"], d["shifts"][-1]["end"], d.get("country", "CZ"))
                    render_html(d["shifts"], d["year"], d["plan_type"], d["shift_config"], d["times"], holidays, d["absences"], d["comp_days"], self.current_files["html"])
                    
                    self.refresh_stats_table()
                    messagebox.showinfo("Done", "Absence processed")
            except: pass

    def do_apply_backfill_changes(self):
        d = load_schedule(self.current_files["data"])
        if d:
            try:
                st = try_parse_date(self.entry_bf_start.get())
                en = try_parse_date(self.entry_bf_end.get())
                rs, ro = self.combo_bf_shift.get(), self.combo_bf_oncall.get()
                
                if not st or not en: return

                u = 0
                for s in d["shifts"]:
                    if not (s['end'] < st or s['start'] > en):
                        if rs:
                            for k in ['early','central','late']:
                                v=s.get(k)
                                if v=="VACANT": s[k]=rs; u+=1
                                elif isinstance(v, list) and "VACANT" in v: v.remove("VACANT"); v.append(rs); s[k]=v; u+=1
                        if ro and s.get('oncall')=="VACANT": s['oncall']=ro; u+=1
                if u:
                    save_schedule(d["shifts"], d["year"], d["plan_type"], d["shift_config"], d["times"], d["staffing"], d["country"], d["absences"], d["comp_days"], self.current_files["data"]); render_html(d["shifts"], d["year"], d["plan_type"], d["shift_config"], d["times"], get_holidays_range(d["shifts"][0]["start"], d["shifts"][-1]["end"], d["country"]), d["absences"], d["comp_days"], self.current_files["html"]); self.refresh_stats_table()
                    messagebox.showinfo("Success", f"Updated {u} slots")
            except: pass

    # --- TAB 5: SKILL MATRIX & STATS ---
    def setup_stats_tab(self):
        container = ttk.Frame(self.tab_stats)
        container.pack(fill=BOTH, expand=True)

        btn_frame = ttk.Frame(container)
        btn_frame.pack(side=TOP, fill=X, pady=10)
        ttk.Button(btn_frame, text="REFRESH ALL DATA", command=self.refresh_stats_table, bootstyle="success-outline").pack()

        self.skill_matrix_frame = ttk.Labelframe(container, text="SKILL MATRIX HEATMAP", padding=15, bootstyle="info")
        self.skill_matrix_frame.pack(fill=X, pady=(0, 20))
        
        self.skill_scroll = ScrollableFrame(self.skill_matrix_frame)
        self.skill_scroll.pack(fill=BOTH, expand=True)

        stats_frame = ttk.Labelframe(container, text="SHIFT FAIRNESS STATS", padding=15, bootstyle="primary")
        stats_frame.pack(fill=BOTH, expand=True)
        
        cols = ("Name", "Total", "Early", "Central", "Late", "Weekend", "OnCall")
        self.tree = ttk.Treeview(stats_frame, columns=cols, show="headings", height=8, bootstyle="primary")
        
        for c in cols:
            self.tree.heading(c, text=c)
            self.tree.column(c, width=80, anchor="center")
            
        self.tree.pack(side=LEFT, fill=BOTH, expand=True)
        
        sb = ttk.Scrollbar(stats_frame, orient=VERTICAL, command=self.tree.yview)
        sb.pack(side=RIGHT, fill=Y)
        self.tree.configure(yscrollcommand=sb.set)

    def refresh_stats_table(self):
        # 1. Refresh Skill Matrix Grid
        inner = self.skill_scroll.scrollable_window
        for w in inner.winfo_children(): w.destroy()
        
        if not self.members: return

        # Get all unique skills across team
        all_skills = sorted(list(set([s for m in self.members for s in m.get("skills", {}).keys()])))
        
        if not all_skills:
            ttk.Label(inner, text="No skills defined in Member Profiles.", foreground="gray").pack(pady=10, padx=10)
        else:
            # --- USE GRID FOR PERFECT ALIGNMENT ---
            
            # A. Header Row (Row 0)
            ttk.Label(inner, text="Team Member", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w", padx=10, pady=10)
            
            for col, skill in enumerate(all_skills):
                # width=15 ensures headers match the data blocks below
                ttk.Label(inner, text=skill, font=("Segoe UI", 9, "bold"), width=15, anchor="center").grid(row=0, column=col+1, padx=2, pady=10)
            
            # B. Separator (Row 1)
            ttk.Separator(inner).grid(row=1, column=0, columnspan=len(all_skills)+1, sticky="ew", pady=(0, 10))

            # C. Data Rows (Row 2+)
            for row_idx, m in enumerate(self.members):
                curr_row = row_idx + 2
                
                # Name Column
                ttk.Label(inner, text=m["name"], font=("Segoe UI", 10)).grid(row=curr_row, column=0, sticky="w", padx=10, pady=2)
                
                # Skill Columns
                for col_idx, s in enumerate(all_skills):
                    val = m.get("skills", {}).get(s, 0)
                    
                    # Color coding logic
                    bstyle = "secondary"
                    if val >= 4: bstyle = "success"    # Green for Expert
                    elif val == 3: bstyle = "info"     # Blue for Intermediate
                    elif val > 0: bstyle = "warning"   # Yellow for Beginner
                    
                    # Display text
                    disp_text = str(val) if val > 0 else "-"
                    # Use -inverse style to get the solid colored block background
                    style_use = f"{bstyle}-inverse" if val > 0 else "secondary"
                    
                    # Ensure width matches the header
                    lbl = ttk.Label(inner, text=disp_text, width=15, anchor="center", bootstyle=style_use)
                    lbl.grid(row=curr_row, column=col_idx+1, padx=2, pady=2)

        # 2. Refresh Fairness Stats (Existing Logic)
        [self.tree.delete(i) for i in self.tree.get_children()]
        data = load_schedule(self.current_files["data"])
        if not data: return
        
        stats = {m["name"]: {"Early":0,"Central":0,"Late":0,"Weekend":0,"OnCall":0} for m in self.members}
        stats["VACANT"] = {"Early":0,"Central":0,"Late":0,"Weekend":0,"OnCall":0}

        for s in data["shifts"]:
            for role in ["early","central","late","weekend","oncall"]:
                val = s.get(role); key = role.capitalize() if role != "oncall" else "OnCall"
                if not val: continue
                
                names = val if isinstance(val, list) else [val]
                for name in names:
                    if name in stats: 
                        stats[name][key] += 1
                    elif name == "VACANT":
                        stats["VACANT"][key] += 1

        for name, c in stats.items():
            if name == "VACANT" and sum(c.values()) == 0: continue
            self.tree.insert("", "end", values=(name, c["Early"]+c["Central"]+c["Late"]+c["Weekend"], c["Early"], c["Central"], c["Late"], c["Weekend"], c["OnCall"]))

    def lock_features_license(self):
        def disable_controls_in_frame(frame):
            for child in frame.winfo_children():
                if isinstance(child, (ttk.Button, ttk.Entry, ttk.Combobox, ttk.Spinbox, ttk.Checkbutton, ttk.Radiobutton)):
                    if "REFRESH" not in str(child.cget("text")):
                        try: child.configure(state="disabled")
                        except: pass
                if isinstance(child, (ttk.Frame, ttk.Labelframe)):
                    disable_controls_in_frame(child)

        disable_controls_in_frame(self.tab_gen)
        disable_controls_in_frame(self.tab_swap)

    def show_license_warning(self):
        messagebox.showwarning("Free Version", 
                               f"UNREGISTERED: {self.license_msg}\n\n"
                               "VIEW MODE only Active.\n\n" \
                               "Manage Teams & Members freely.\n" \
                               "Generate & Swap features are locked.\n\n" \
                               "To Get 10 Days free Trial\n" \
                               "One Click at the red button Lincence\n" \
                               "Copy the HWID and send it via mail to:\n\n" \
                               "makremmazroui@gmail.com"
                                )

    def create_activation_banner(self):
        pass 

    def open_activation_window(self):
        hwid = LicenseManager.get_hwid()
        win = ttk.Toplevel(self)
        win.title("Activate License")
        win.geometry("500x400")
        
        ttk.Label(win, text="1. Send this Hardware ID to the developer:", font=("Arial", 10, "bold")).pack(pady=(15,5))
        f1 = ttk.Frame(win)
        f1.pack(fill=X, padx=20)
        e_hwid = ttk.Entry(f1, justify="center")
        e_hwid.insert(0, hwid)
        e_hwid.config(state="readonly")
        e_hwid.pack(side=LEFT, fill=X, expand=True)
        ttk.Button(f1, text="Copy", command=lambda: [self.clipboard_clear(), self.clipboard_append(hwid), messagebox.showinfo("Copied","ID Copied")]).pack(side=LEFT, padx=5)
        
        ttk.Label(win, text="2. Paste your Licence Key below:", font=("Arial", 10, "bold")).pack(pady=(20,5))
        txt_key = tk.Text(win, height=5, width=50, bd=1, relief="solid", bg="white")
        txt_key.pack(padx=20, pady=5)
        
        def attempt_activate():
            key = txt_key.get("1.0", tk.END).strip()
            if not key: messagebox.showerror("Error", "Please paste the license key first."); return
            LicenseManager.save_license(key)
            valid, msg, exp = LicenseManager.verify_license()
            if valid:
                messagebox.showinfo("Success", f"Activation Successful!\nValid until: {exp}\nPlease restart the application.")
                win.destroy(); self.destroy() 
            else:
                messagebox.showerror("Failed", f"Activation Failed:\n{msg}")
                if os.path.exists(LicenseManager.LICENSE_FILE): os.remove(LicenseManager.LICENSE_FILE)
        ttk.Button(win, text="ACTIVATE LICENSE", command=attempt_activate, bootstyle="success").pack(pady=15)

    def load_initial_config(self):
        if not self.current_team_name: return
        data = load_schedule(self.current_files["data"])
        if not data: return
        if "country" in data: self.combo_country.set(data["country"])
        if "staffing" in data:
            if "early" in data["staffing"]: self.spin_early_count.set(data["staffing"]["early"])
            if "late" in data["staffing"]: self.spin_late_count.set(data["staffing"]["late"])
        if "plan_type" in data: self.var_type.set(data["plan_type"])
        if "shift_config" in data: self.combo_shifts.set(data["shift_config"])
        if "comp_days" in data and len(data["comp_days"]) == 2:
            d1, d2 = data["comp_days"]
            days_map_inv = {0: "Monday", 1: "Tuesday", 2: "Wednesday", 3: "Thursday", 4: "Friday"}
            self.combo_comp1.set(days_map_inv.get(d1, "Thursday"))
            self.combo_comp2.set(days_map_inv.get(d2, "Friday"))
        self.update_visibility()
        self.refresh_stats_table()

if __name__ == "__main__":
    app = ShiftPlannerApp()
    app.mainloop()
