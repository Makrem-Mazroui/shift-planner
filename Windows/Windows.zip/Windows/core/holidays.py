from datetime import datetime, timedelta

def get_easter_date(year):
    a = year % 19
    b = year // 100
    c = year % 100
    d = b // 4
    e = b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i = c // 4
    k = c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = ((h + l - 7 * m + 114) % 31) + 1
    return datetime(year, month, day)

def get_public_holidays(year, country_code="CZ"):
    holidays = {}
    easter = get_easter_date(year)
    
    def add(d, m, name):
        try: holidays[datetime(year, m, d)] = name
        except: pass

    def add_rel(days_offset, name):
        holidays[easter + timedelta(days=days_offset)] = name

    if country_code == "CZ":
        add(1, 1, "New Year"); add_rel(-2, "Good Friday"); add_rel(1, "Easter Monday")
        add(1, 5, "Labor Day"); add(8, 5, "Liberation Day"); add(5, 7, "Cyril/Methodius")
        add(6, 7, "Jan Hus"); add(28, 9, "St. Wenceslas"); add(28, 10, "Indep. Day")
        add(17, 11, "Freedom/Democracy"); add(24, 12, "Christmas Eve"); add(25, 12, "Christmas 1"); add(26, 12, "Christmas 2")
    elif country_code == "SK":
        add(1, 1, "Republic Day"); add(6, 1, "Epiphany"); add_rel(-2, "Good Friday"); add_rel(1, "Easter Monday")
        add(1, 5, "Labor Day"); add(8, 5, "Victory Day"); add(5, 7, "Cyril/Methodius"); add(29, 8, "SNP")
        add(1, 9, "Constitution"); add(15, 9, "Lady Sorrows"); add(1, 11, "All Saints"); add(17, 11, "Freedom")
        add(24, 12, "Christmas Eve"); add(25, 12, "Christmas 1"); add(26, 12, "Christmas 2")
    elif country_code == "DE":
        add(1, 1, "Neujahr"); add_rel(-2, "Karfreitag"); add_rel(1, "Ostermontag"); add(1, 5, "Tag der Arbeit")
        add_rel(39, "Himmelfahrt"); add_rel(50, "Pfingstmontag"); add(3, 10, "Deutsche Einheit")
        add(25, 12, "Weihnachten 1"); add(26, 12, "Weihnachten 2")
    elif country_code == "UK":
        add(1, 1, "New Year"); add_rel(-2, "Good Friday"); add_rel(1, "Easter Monday")
        add(1, 5, "May Bank Hol"); add(25, 12, "Christmas"); add(26, 12, "Boxing Day")
    elif country_code == "US":
        add(1, 1, "New Year"); add(4, 7, "Independence"); add(11, 11, "Veterans"); add(25, 12, "Christmas")
    elif country_code == "FR":
        add(1, 1, "Jour de l'an"); add_rel(1, "Pâques"); add(1, 5, "Travail"); add(8, 5, "Victoire")
        add_rel(39, "Ascension"); add_rel(50, "Pentecôte"); add(14, 7, "Nationale"); add(15, 8, "Assomption")
        add(1, 11, "Toussaint"); add(11, 11, "Armistice"); add(25, 12, "Noël")
    elif country_code == "PL":
        add(1, 1, "New Year"); add(6, 1, "Epiphany"); add_rel(1, "Easter Monday"); add(1, 5, "Labor Day")
        add(3, 5, "Constitution"); add_rel(60, "Corpus Christi"); add(15, 8, "Army Day"); add(1, 11, "All Saints")
        add(11, 11, "Independence"); add(25, 12, "Christmas"); add(26, 12, "Boxing Day")

    return holidays

def get_holidays_range(start_date, end_date, country="CZ"):
    years = range(start_date.year, end_date.year + 1)
    all_holidays = {}
    for y in years:
        all_holidays.update(get_public_holidays(y, country))
    return all_holidays